/* @Duy */

const styles = {
  Card: {
    marginLeft:10,
    marginRight:10,
    height:45,
    justifyContent:'center',
    alignItems:'center'
  },
  iconLeft:{
    color:'#2BA6E2'
  },
  nameBody:{
    justifyContent:'center',
    marginRight:180
  },
  txtBody:{
    width:188,
    color:'black',
    fontSize:18,
  },
  iconRight:{
    color:'black',
    marginLeft:10,
  },
  txtDate:{
    marginRight:-10,
    fontSize:10,
    width:55
  }
}

export default styles;
